
document.write("This is our javascript being written first before anything else");